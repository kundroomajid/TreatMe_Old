<?php include("header.php"); ?>
<main>
	<div class="hero_home version_2">
		<div class="content">
		 <font size="10">TreatMe </font>
			<p><b><font color="red" size="6">Sorry you are offline at the moment!</font></b></p>
	    </div>
	</div>
</main>
</body>
</html>
<?php include("footer.php"); ?>
