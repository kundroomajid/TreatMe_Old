# Rating
Star rating system is a quite useful feature when you want to understand about your audience’s opinion on your products. Most of the website owners implement this feature in order to know whether their products meet customers’ expectations or not. 
Also, I’ve created a demo on [Building Star Rating in PHP Using JQuery And AJAX](https://www.spaceotechnologies.com/star-rating-in-php-jquery-ajax-css/). 

If you face any issue implementing it, you can contact me for help. Also, if you want to implement this feature in your PHP website and looking to [Hire PHP developer](http://www.spaceotechnologies.com/hire-php-developer/ ) to help you, then you can contact Space-O Technologies for the same.
