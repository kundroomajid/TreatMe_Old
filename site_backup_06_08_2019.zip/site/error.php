<?php
$user_email="kundroomajid@gmail.com";
$hash="kljsllsdjklasjjksd";




echo ('<html>
<div style="margin:0;padding:0;width:100%!important">
  <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#DDDDDD" style="width:100%;background:#dddddd">
    <tbody>
      <tr>
        <td>
          <table border="0" cellspacing="0" cellpadding="0" align="center" width="550" style="width:100%;padding:10px">
            <tbody>
              <tr>
                <td>
                  <div style="direction:ltr;max-width:600px;margin:0 auto">
                    <table border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff" style="width:100%;background-color:#fff;text-align:left;margin:0 auto;max-width:1024px;min-width:320px">
                      <tbody>
                        <tr>
                          <td>
                            <table width="100%" border="0" cellspacing="0" cellpadding="0" height="8" background="https://ci4.googleusercontent.com/proxy/URvE_Cd0IgwinMXzb6MwJQyP1lEuYJMlw7iyrNYSJSH9HhA4F3B0RPWC7SxswYqlxE-Gjc_npi1i=s0-d-e1-ft#https://s0.wp.com/i/emails/stripes.gif" style="width:100%;background-image:url("https://ci4.googleusercontent.com/proxy/URvE_Cd0IgwinMXzb6MwJQyP1lEuYJMlw7iyrNYSJSH9HhA4F3B0RPWC7SxswYqlxE-Gjc_npi1i=s0-d-e1-ft#https://s0.wp.com/i/emails/stripes.gif");background-repeat:repeat-x;background-color:#43a4d0;height:8px">
                              <tbody>
                                <tr>
                                  <td></td>
                                </tr>
                              </tbody>
                            </table>
                            <table width="100%" border="0" cellspacing="0" cellpadding="0" style="width:100%;background-color:#efefef;padding:0;border-bottom:1px solid #ddd">
                              <tbody>
                                <tr>
                                  <td>
                                    <h2 style="padding:0;margin:5px 20px;font-size:16px;line-height:1.4em;font-weight:normal;color:#464646;font-family:&quot;Helvetica Neue&quot;,Helvetica,Arial,sans-serif">Please confirm your Email Address for <strong>TreatMe.co.in</strong></a></h2>
                                  </td>

                                </tr>
                              </tbody>
                            </table>
                            <table style="width:100%" width="100%" border="0" cellspacing="0" cellpadding="20" bgcolor="#ffffff">
                              <tbody>
                                <tr>
                                  <td>
                                    <table style="width:100%" border="0" cellspacing="0" cellpadding="0">
                                      <tbody>
                                        <tr>
                                          <td valign="top">
                                            <p style="direction:ltr;font-size:14px;line-height:1.4em;color:#444444;font-family:&quot;Helvetica Neue&quot;,Helvetica,Arial,sans-serif;margin:0 0 1em 0">Welcome .<br><br>
                                              To activate your account please click confirm below. If you believe this is an error, ignore this message and we"ll never bother you again.</p>
                                              <a href="https://shifaddnn.000webhostapp.com/shifa/verify.php?email='.$user_email.'&hash='.$hash.'">Confirm Here</a>
                                          

                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
                                  </td>
                </td>
              </tr>
            </tbody>
          </table>
        </td>
      </tr>
    </tbody>
  </table>
  </div>
  </div>
</html>');
                                                ?>