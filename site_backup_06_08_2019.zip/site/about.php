<?php
include("header.php");?>

<main>
		
		
		<div class="container margin_60_35">
<div class="row">
	<aside class="col-lg-3 col-md-4">
					<div id="contact_info">
						<br /> <br />
						<br /> <br />
						<h3>Contacts info</h3>
						<p>
							IUST AWANTIPORA <br /> <br />
							feedback@treatme.co.in
							
						</p>
						
					</div>
				</aside>
				<div class=" col-lg-8 col-md-8 ml-auto">
					<div align = "center"><img src="img/logo_2x.png" alt="logo" width="50%" /></div>
					<h6> About TreatMe</h6>
					<p> TreatMe is the source for appropriate doctor search, appointment booking of doctors and up-to-date doctor ratings and reviews. </p>
					<p>Online appointment booking system save time and money and also provide patients and doctors much information about upcoming appointments. It helps to provide better healthcare experience by providing high satisfaction, continuing patient engagement remotely. From anywhere you can make your appointment from your busy schedule.Booking an appointment online can make the process strees free. You can see when the doctor is available and which facility around the clock. You can book an appointment at your convenience and make the time to plan out your visit well ahead.you can also be sure that your slot is confirmed.</p>
					<p>When it comes to your health, finding the right doctor should only be a click away. This site gives patients and medical professionals a voice, helping connect healthcare providers and facilities with those in need of medical care.</p>

					<p>This site provides information, reviews and ratings on everything from cleanliness of hospital and care center facilities, to physician knowledge, as well as giving patients the ability to share their own personal experiences.</p>

					<p>The ratings platform and doctor search allow you to locate specialists in your area and get informed through other patients' experiences and testimonials. Whether you're looking for a new Family Doctor, General Practitioner, or you're seeking a specialist like a Dentist or Neurologist, we've got you covered.</p>

					<p>Physician rating websites can be an innovative idea to empower patients to make informed choices while selecting healthcare providers for advice and treatment.</p>
					
					
					<p> Given the wide applicability of recently proposed framework of deep learning to manage BigData, we build an AI system trained on reviews, feedback and comments of Medical Industry using Deep Learning.  This proposed artificially intelligent algorithm will learn patient satisfaction from textual reviews, comments and suggest improvements for better services. The AI system shall act as a recommender and an automated feedback system. The front-end of our product is a web portal and mobile application and back end a deep neural network model. Service user’s negative comments will be identified and remedial measure learned from reviews shall be recommended.</p>

		</div>
			
	</div>
		<!-- /container -->
	</main>
	<!-- /main -->
<?php
include("footer.php");?>